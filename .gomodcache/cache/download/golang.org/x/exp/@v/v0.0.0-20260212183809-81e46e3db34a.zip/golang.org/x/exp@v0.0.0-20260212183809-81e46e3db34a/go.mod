module golang.org/x/exp

go 1.25.0

require (
	github.com/google/go-cmp v0.6.0
	golang.org/x/mod v0.33.0
	golang.org/x/tools v0.42.0
	golang.org/x/tools/go/packages/packagestest v0.1.1-deprecated
)

require (
	golang.org/x/sync v0.19.0 // indirect
	golang.org/x/tools/go/expect v0.1.1-deprecated // indirect
)
